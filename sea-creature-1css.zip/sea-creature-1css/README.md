# Sea Creature #1 - CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/BaVbYGv](https://codepen.io/josetxu/pen/BaVbYGv).

