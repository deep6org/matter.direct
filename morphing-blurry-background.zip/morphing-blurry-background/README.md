# Morphing Blurry Background

A Pen created on CodePen.io. Original URL: [https://codepen.io/moskalyk-the-lessful/pen/MWVGLRe](https://codepen.io/moskalyk-the-lessful/pen/MWVGLRe).

